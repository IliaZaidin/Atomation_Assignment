export interface BreweryItem {
  name: string;
  city: string;
  image: string;
}
